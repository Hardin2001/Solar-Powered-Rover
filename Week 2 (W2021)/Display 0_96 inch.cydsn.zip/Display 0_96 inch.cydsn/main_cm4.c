/* ========================================
 *
 *  ---------------THIS PROJECT NOT WORKING---------------
 *
    * Text example for the Stirling And District Amateur Radio Club 
 *
 * ========================================
*/
#include "project.h"
#include "U8g2lib.h"

int main(void)
{
    __enable_irq(); /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    // Set up the PSoC6 I2C master
    I2C_Start();
    
    // U8g2 Contructor List (Frame Buffer)
    U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);   // HW I2C with pin remapping
    // End of constructor list

// Declare variables
uint8_t frametopleft_x=12;
uint8_t frametopleft_y=6;
uint8_t framewidth=100;
uint8_t frameheight=54;
uint8_t framecorner=6;
uint8_t hline_x=12;
uint8_t hline_y=42;
uint8_t hline_w=100;


void setup(void) {
  u8g2.begin();
}


    for(;;)
    {
        /* Place your application code here. */
        
        u8g2.clearBuffer();         // clear the internal memory
        // Draw  frame with rounded corners, and horizontal line to separate text rows
        u8g2.drawRFrame(frametopleft_x, frametopleft_y, framewidth, frameheight, framecorner);
        u8g2.drawHLine(hline_x, hline_y, hline_w);
        // Add lower line of text
        u8g2.setFont(u8g2_font_ncenB08_tf); // choose a suitable font
        u8g2.drawStr(22,54,"Amateur Radio");  // write something to the internal memory
        u8g2.sendBuffer();          // transfer internal memory to the display
        delay(1000);    
        // Add upper line of text
        u8g2.setFont(u8g2_font_fub14_tr); // choose a suitable font
        u8g2.drawStr(22,30,"SADARS");  // write something to the internal memory
        u8g2.sendBuffer();          // transfer internal memory to the display
        delay(1000); 
    }
}

/* [] END OF FILE */
